import React from "react";

function App() {
    return (
        <div>
            <div>
                <h1>Hello</h1>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. In
                    dolorum deserunt quod unde dolorem quo ratione ipsam culpa
                    porro cumque quaerat eaque temporibus facere mollitia ipsa
                    suscipit, natus similique voluptate.
                </p>
            </div>
        </div>
    );
}

export default App;
